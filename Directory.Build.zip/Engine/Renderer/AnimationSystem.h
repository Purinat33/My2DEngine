#pragma once
namespace my2d
{
    class Engine;
    class Scene;

    void AnimationSystem_Update(Engine& engine, Scene& scene, float dt);
}